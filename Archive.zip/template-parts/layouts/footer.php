<footer class="footer uk-light">
    <div class="uk-section footer__top uk-background-norepeat uk-background-bottom-center" data-src="images/bgfooter-02.png" uk-img>
        <div class="uk-container uk-container-large">
            <div class="uk-child-width-1-3@l" uk-grid>
                <div>
                    <figure><a href=""><img src="images/Layer89.png" alt=""></a></figure>
                    <div>
                        <a href="" class="uk-icon-button uk-margin-small-right" uk-icon="twitter"></a>
                        <a href="" class="uk-icon-button  uk-margin-small-right" uk-icon="facebook"></a>
                        <a href="" class="uk-icon-button" uk-icon="youtube"></a>
                    </div>
                </div>
                <div>
                    <div class="footer__top__box1">
                        <div>Hệ thống Trường EMASI</div>
                        <div>+ EMASI Nam Long</div>
                        <div>+ EMASI Vạn Phúc</div>
                        <div>+ EMASI Plus Waterpoint</div>
                    </div>
                    <ul class="uk-list footer__top__list uk-margin-medium-top">
                        <li><span class="uk-margin-small-right" uk-icon="icon: receiver"></span>1800 599 918</li>
                        <li><span class="uk-margin-small-right" uk-icon="icon: mail"></span>tuyensinh@emasi.edu.vn</li>
                    </ul>
                </div>
                <div>
                    <figure><a href=""><img src="images/Layer76.png" alt=""></a></figure>
                </div>
            </div>
        </div>
    </div>
    <div class="footer__bottom">
        <div class="uk-container">
            <div class="footer__bottom__txt">Ⓒ EMASI SCHOOLS</div>
        </div>
    </div>
</footer>
</div>
<!--/app-->
</body>
</html>